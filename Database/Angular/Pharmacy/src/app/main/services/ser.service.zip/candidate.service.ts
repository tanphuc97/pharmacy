import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Candidate } from "src/entitites/candidate.entity";
import { lastValueFrom } from "rxjs";
import { Category } from "src/entitites/category.entity";


@Injectable()
export class CandidateService{
    private BASE_URL: string = 'http://localhost:5235/api/candidate/';
    private SAVEFILE_URL: string = 'http://localhost:5235/api/fileuploads/upload';
    constructor(
        private httpClient: HttpClient
    ){}
    async create (candidate : Candidate){
        
        var value= this.httpClient.post(this.BASE_URL+'create',candidate);
         return await lastValueFrom(value)
     }

     async delete (id : number){
        
        var value= this.httpClient.delete(this.BASE_URL+'delete'+'/'+id);
         return await lastValueFrom(value)
     }

     async find (id: number){
        var value= this.httpClient.get(this.BASE_URL+'find'+'/'+id);
         return await lastValueFrom(value)
     }

     async findall (){
        var value= this.httpClient.get(this.BASE_URL+'findall');
         return await lastValueFrom(value)
     }
     async searchbykeyword(keyword:string){
        var value= this.httpClient.get(this.BASE_URL+'searchbykeyword'+'/'+keyword);
         return await lastValueFrom(value)
     }

     async saveFile (file : File){
         var fd = new FormData();
         fd.append('file',file,file.name);
        var value= this.httpClient.post(this.SAVEFILE_URL,fd);
         return await lastValueFrom(value)
     }

     
    
}