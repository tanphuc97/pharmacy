import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { lastValueFrom } from "rxjs";
import { BASE_URL } from "src/entitites/BASE_URL.entities";

@Injectable()
export class ProductService{
    BASE_URL : BASE_URL 
    constructor(
        private httpClient: HttpClient
    ){}

    async showproduct (phonenumber:string){
        var value= this.httpClient.get(this.BASE_URL+'showproduct'+'/'+phonenumber);
         return await lastValueFrom(value)
     }
     async find (phonenumber:string){
        var value= this.httpClient.get(this.BASE_URL+'showproduct'+'/'+phonenumber);
         return await lastValueFrom(value)
     }
}