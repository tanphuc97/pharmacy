import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { lastValueFrom } from "rxjs";
import { Feedback } from "src/entitites/feedback.entitty";


@Injectable()
export class FeedbackService{
    BASE_URL : string='http://localhost:5235/api/feedback/';
    constructor(
        private httpClient: HttpClient
    ){}
    async create (feedback : Feedback){
        var value= this.httpClient.post(this.BASE_URL+'create',feedback);
         return await lastValueFrom(value)
     }

}