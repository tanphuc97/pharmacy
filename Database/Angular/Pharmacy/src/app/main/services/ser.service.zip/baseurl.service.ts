import { Injectable } from "@angular/core";

@Injectable()
//= 'http://localhost:5235/api/'
export class BASE_URLSerVice{
    URL(){
        return 'http://localhost:5235/api/';
    };
    URLAccount(){
        return this.URL() +'account/';
    };
    URLCandidate(){
        return this.URL()+ 'candidate/';
    };
    URLFeedback(){
        return this.URL()+'feedback/';
    };
    URLJobinformation (){
        return this.URL()+'jobinformation/';
    }
}