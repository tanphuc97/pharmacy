import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { lastValueFrom } from "rxjs";
import { BASE_URL } from "src/entitites/BASE_URL.entities";
import { JobInformation } from "src/entitites/jobinformation.entity";
import { BASE_URLSerVice } from "./baseurl.service";



@Injectable()
export class JobInformationService{
    
    //private BASE_URL: string = this.url.URL+'jobinformation';
    private SAVEFILE_URL: string = 'http://localhost:5235/api/fileuploads/upload';
    constructor(
        private httpClient: HttpClient,
        private BASE_URL : BASE_URLSerVice
    ){}
    async create (jobInformation : JobInformation){
        
        var value= this.httpClient.post(this.BASE_URL.URLJobinformation()+'create',jobInformation);
         return await lastValueFrom(value)
     }

     async searchbykeyword (keyword:string){
        
        var value= this.httpClient.get(this.BASE_URL.URLJobinformation()+'searchbykeyword'+'/'+keyword);
         return await lastValueFrom(value)
     }
     async delete (id:number){
        
        var value= this.httpClient.delete(this.BASE_URL.URLJobinformation()+'delete'+'/'+id);
         return await lastValueFrom(value)
     }

     async find (id:number){
        
        var value= this.httpClient.get(this.BASE_URL.URLJobinformation()+'find'+'/'+id);
         return await lastValueFrom(value)
     }
     async update (jobInformation : JobInformation){
        
        var value= this.httpClient.put(this.BASE_URL.URLJobinformation()+'update',jobInformation);
         return await lastValueFrom(value)
     }
  

     async findall (){
        var value= this.httpClient.get(this.BASE_URL.URLJobinformation()+'findall');
         return await lastValueFrom(value)
     }

     async saveFile (file : File){
         var fd = new FormData();
         fd.append('file',file,file.name);
        var value= this.httpClient.post(this.SAVEFILE_URL,fd);
         return await lastValueFrom(value)
     }

}