import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { lastValueFrom } from "rxjs";


@Injectable()
export class ClientService{
    BASE_URL : string='http://localhost:5235/api/client/';
    constructor(
        private httpClient: HttpClient
    ){}
    async find(phonenumber:string){
        var value= this.httpClient.get(this.BASE_URL+'find'+'/'+phonenumber);
         return await lastValueFrom(value)
     }

}