export class JobInformation{
    id:number;
    description:string;
    jobName: string;
    quantity: number;
    location: string;
    status : boolean;
    created : Date;

}