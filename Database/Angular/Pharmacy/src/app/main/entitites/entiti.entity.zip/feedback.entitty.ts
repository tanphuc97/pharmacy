

export class Feedback{
    id:number;
    clientid:number;
    content:string;
    productid:number;
    title:string;
}