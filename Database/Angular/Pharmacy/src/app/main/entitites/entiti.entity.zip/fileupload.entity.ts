import { AnyAaaaRecord } from "dns";

export class FileUpload{
    files: any;
}