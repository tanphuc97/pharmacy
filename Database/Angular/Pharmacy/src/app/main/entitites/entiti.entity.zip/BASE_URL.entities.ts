export class BASE_URL{
   URL :string;
    
}