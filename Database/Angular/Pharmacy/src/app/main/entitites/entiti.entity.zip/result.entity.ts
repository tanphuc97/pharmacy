
export class Result{
    result:boolean;
}
